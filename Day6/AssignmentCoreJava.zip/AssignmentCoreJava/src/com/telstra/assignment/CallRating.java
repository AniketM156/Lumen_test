package com.telstra.assignment;

public class CallRating {
	 String callid;
	 int callDuration;
	 double callQuality;
	 String ratingCategory;
	 
	 public CallRating(String callid, double callQuality , int callDuration , String ratingCategory){
		 this.callid = callid;
		 this.callQuality = callQuality;
		 this.callDuration = callDuration;
		 this.ratingCategory = ratingCategory;
	}

}
