package com.telstra.assignment;

import CallRating;

public class CallRatingSystem {
	public static CallRating[] rateCalls(int[] callDurations, double[] callQualities) {
		int call_length = callDurations.length;
		CallRating[] ratingList = new CallRating[call_length];
		
		for(int i = 0;i<call_length;i++) {
			 String callid = "Caller id is " + i;
			 double callQuality = callQuality[i];
			 int callDuration = callDuration[i];
			 double temp = callQuality/callDuration;
			 String ratingCategory;
			 if(temp >=0.08) ratingCategory = "Excellent";
			 else if (temp>0.08 && temp>=0.05) ratingCategory = "Good";
			 else ratingCategory = "Average";
			 
			 ratingList[i] = new CallRating(callid , callQuality , callDuration , ratingCategory);
			 System.out.println(callid + " Call Duration: " + callDuration + " minutes, Call Quality:" + callQuality + ", Rating Category: " + ratingCategory);
		}
		
		
	}
	
	
	public static void main(String[] args) {
		int[] callDurations = {5,10,7,8,15};
		double[] callQualities = {0.35,0.48,0.21,0.12,0.30};
		
		int l = callDurations.length;
		for(int i = 0;i<l;i++) {
			CallRating rating = rateCalls(callDurations[i],callQualities[i]);
		}

	}

}
